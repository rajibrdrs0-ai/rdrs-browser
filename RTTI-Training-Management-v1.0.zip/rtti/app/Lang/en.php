<?php
return [];  // English is the source language: keys are shown as-is.
