'use strict';
// RDRS Browser — main process
const { app, BrowserWindow, session, protocol, ipcMain, net, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');

protocol.registerSchemesAsPrivileged([
  { scheme: 'rdrs', privileges: { standard: true, secure: true, supportFetchAPI: true } }
]);

const PAGES_DIR = path.join(__dirname, 'pages');
const PROGRAM_DATA = process.env.ProgramData || 'C:\\ProgramData';
// Machine-wide policy written by IT (highest precedence)
const MACHINE_POLICY = path.join(PROGRAM_DATA, 'RDRS', 'Browser', 'policy.json');
const USER_DIR = () => app.getPath('userData');
const file = (name) => path.join(USER_DIR(), name);

const INCOGNITO_PARTITION = 'rdrs-incognito';
const MAX_HISTORY = 5000;

// ---------- helpers ----------
function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; }
}
function writeJson(p, data) {
  try { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, JSON.stringify(data, null, 2)); }
  catch (e) { console.error('write failed', p, e.message); }
}

// Precedence: built-in defaults < management server < machine policy file
function loadPolicy() {
  const defaults = readJson(path.join(__dirname, 'policy.default.json'), {});
  const remote = readJson(file('remote-policy.json'), {});
  const machine = readJson(MACHINE_POLICY, {});
  return Object.assign({}, defaults, remote, machine);
}
let policy = loadPolicy();

function deviceId() {
  const p = file('device.json');
  let d = readJson(p, null);
  if (!d || !d.id) { d = { id: crypto.randomUUID(), created: new Date().toISOString() }; writeJson(p, d); }
  return d.id;
}

function hostMatches(host, pattern) {
  const p = String(pattern).toLowerCase().trim().replace(/^\*\./, '').replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  return p && (host === p || host.endsWith('.' + p));
}
function isUrlAllowed(url) {
  let u;
  try { u = new URL(url); } catch { return true; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return true;
  const host = u.hostname.toLowerCase();
  if ((policy.urlAllowlist || []).some((p) => hostMatches(host, p))) return true;
  if (policy.allowlistOnly) return false;
  return !(policy.urlBlocklist || []).some((p) => hostMatches(host, p));
}

function sendToHost(wc, channel, ...args) {
  try {
    const host = wc && (wc.hostWebContents || wc);
    if (host && !host.isDestroyed()) host.send(channel, ...args);
  } catch { /* window closed */ }
}

// ---------- rdrs:// internal pages ----------
const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json' };

function rdrsHandler(request, callback) {
  try {
    const u = new URL(request.url);
    const page = u.hostname;
    const rel = decodeURIComponent(u.pathname.replace(/^\/+/, ''));

    if (page === 'newtab' && rel === 'config.json') {
      return callback({ mimeType: 'application/json', data: Buffer.from(JSON.stringify({
        orgName: policy.orgName, searchUrl: policy.searchUrl, quickLinks: policy.quickLinks || [], announcement: policy.announcement || ''
      })) });
    }
    if (page === 'history' && rel === 'data.json') {
      // only the history page itself may read this
      const ref = String(request.referrer || '');
      if (ref && !ref.startsWith('rdrs://history')) return callback({ statusCode: 403, data: Buffer.from('') });
      return callback({ mimeType: 'application/json', data: Buffer.from(JSON.stringify(readJson(file('history.json'), []))) });
    }

    const target = path.resolve(PAGES_DIR, rel || `${page}.html`);
    if (!target.startsWith(PAGES_DIR) || !fs.existsSync(target)) return callback({ statusCode: 404, data: Buffer.from('Not found') });
    callback({ mimeType: MIME[path.extname(target)] || 'application/octet-stream', data: fs.readFileSync(target) });
  } catch (e) {
    callback({ statusCode: 500, data: Buffer.from(String(e.message)) });
  }
}

// ---------- per-session policy ----------
const configured = new WeakSet();
function configureSession(ses) {
  if (!ses || configured.has(ses)) return;
  configured.add(ses);

  ses.protocol.registerBufferProtocol('rdrs', rdrsHandler);
  ses.setUserAgent(`${ses.getUserAgent()} RDRSBrowser/${app.getVersion()}`);

  if (policy.proxy && policy.proxy.proxyRules) {
    ses.setProxy({ proxyRules: policy.proxy.proxyRules, proxyBypassRules: policy.proxy.proxyBypassRules || '<local>' });
  }

  // Website allow/block policy (cancelled loads are shown as the "blocked" page by the UI)
  ses.webRequest.onBeforeRequest((details, cb) => {
    const t = details.resourceType;
    if ((t === 'mainFrame' || t === 'subFrame') && !isUrlAllowed(details.url)) return cb({ cancel: true });
    cb({});
  });

  ses.on('will-download', (event, item, wc) => {
    const name = item.getFilename();
    const ext = path.extname(name).toLowerCase().replace('.', '');
    if (policy.downloadsDisabled || (policy.blockedDownloadExtensions || []).includes(ext)) {
      item.cancel();
      sendToHost(wc, 'toast', `Download blocked by RDRS policy: ${name}`);
      return;
    }
    sendToHost(wc, 'toast', `Downloading ${name}…`);
    item.once('done', (e, state) => {
      if (state === 'completed') sendToHost(wc, 'toast', `Downloaded ${name}`, item.getSavePath());
      else if (state !== 'cancelled') sendToHost(wc, 'toast', `Download failed: ${name}`);
    });
  });

  // Allow only what office web apps need (video calls, notifications); deny location, USB, MIDI, etc.
  ses.setPermissionRequestHandler((wc, permission, cb) => {
    cb(['clipboard-sanitized-write', 'fullscreen', 'notifications', 'media'].includes(permission));
  });
}

// ---------- keyboard shortcuts ----------
function shortcutFor(input) {
  if (input.type !== 'keyDown') return null;
  const k = (input.key || '').toLowerCase();
  const c = input.control || input.meta;
  if (c && input.shift && k === 'n') return 'incognito';
  if (c && input.shift && k === 'i') return 'devtools';
  if (c && k === 't') return 'new-tab';
  if (c && k === 'w') return 'close-tab';
  if (c && k === 'l') return 'focus-address';
  if (c && k === 'd') return 'bookmark';
  if (c && k === 'h') return 'history';
  if (c && k === 'tab') return input.shift ? 'prev-tab' : 'next-tab';
  if (c && k === 'r') return 'reload';
  if (c && k === 'p') return 'print';
  if (c && (k === '=' || k === '+')) return 'zoom-in';
  if (c && k === '-') return 'zoom-out';
  if (c && k === '0') return 'zoom-reset';
  if (k === 'f5') return 'reload';
  if (k === 'f12') return 'devtools';
  if (input.alt && k === 'arrowleft') return 'back';
  if (input.alt && k === 'arrowright') return 'forward';
  return null;
}

app.on('web-contents-created', (e, contents) => {
  // Lock down every <webview> the UI creates
  contents.on('will-attach-webview', (ev, webPreferences, params) => {
    delete webPreferences.preload;
    webPreferences.nodeIntegration = false;
    webPreferences.contextIsolation = true;
    webPreferences.sandbox = true;
    if (params.partition && params.partition !== INCOGNITO_PARTITION) ev.preventDefault();
  });

  contents.on('before-input-event', (ev, input) => {
    const action = shortcutFor(input);
    if (!action) return;
    ev.preventDefault();
    if (action === 'incognito') { if (policy.allowIncognito !== false) createWindow({ incognito: true }); return; }
    sendToHost(contents, 'shortcut', action);
  });

  if (contents.getType() === 'webview') {
    // Links with target=_blank / window.open open as new tabs
    contents.setWindowOpenHandler(({ url }) => {
      sendToHost(contents, 'open-tab', url);
      return { action: 'deny' };
    });
  }
});

app.on('session-created', (ses) => { if (app.isReady()) configureSession(ses); });

// ---------- windows ----------
function createWindow(opts = {}) {
  const win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 560, minHeight: 400,
    title: opts.incognito ? 'RDRS Browser (Incognito)' : 'RDRS Browser',
    icon: path.join(__dirname, 'assets', 'icon.ico'),
    backgroundColor: opts.incognito ? '#20232a' : '#ffffff',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true
    }
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'ui', 'browser.html'), {
    query: { incognito: opts.incognito ? '1' : '0', url: opts.url || '' }
  });
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  return win;
}

function broadcast(channel, ...args) {
  BrowserWindow.getAllWindows().forEach((w) => w.webContents.send(channel, ...args));
}

// ---------- IPC ----------
ipcMain.handle('policy:get', () => ({
  orgName: policy.orgName,
  homepage: policy.homepage || 'rdrs://newtab/',
  searchUrl: policy.searchUrl || 'https://www.google.com/search?q=%s',
  allowDevTools: policy.allowDevTools !== false,
  allowIncognito: policy.allowIncognito !== false,
  managedBookmarks: policy.managedBookmarks || [],
  version: app.getVersion(),
  chromium: process.versions.chrome,
  deviceId: deviceId()
}));

ipcMain.handle('bookmarks:get', () => readJson(file('bookmarks.json'), []));
ipcMain.handle('bookmarks:save', (e, list) => {
  if (!Array.isArray(list)) return false;
  const clean = list.filter((b) => b && typeof b.url === 'string').slice(0, 500)
    .map((b) => ({ title: String(b.title || b.url).slice(0, 200), url: b.url.slice(0, 2048) }));
  writeJson(file('bookmarks.json'), clean);
  return true;
});

let historyCache = null;
let historyTimer = null;
ipcMain.on('history:add', (e, entry) => {
  if (!entry || typeof entry.url !== 'string' || !/^https?:/i.test(entry.url)) return;
  if (!historyCache) historyCache = readJson(file('history.json'), []);
  const last = historyCache[0];
  if (last && last.url === entry.url) { last.title = entry.title || last.title; last.time = Date.now(); }
  else historyCache.unshift({ url: entry.url.slice(0, 2048), title: String(entry.title || '').slice(0, 200), time: Date.now() });
  historyCache.length = Math.min(historyCache.length, MAX_HISTORY);
  clearTimeout(historyTimer);
  historyTimer = setTimeout(() => writeJson(file('history.json'), historyCache), 1500);
});
ipcMain.handle('history:clear', async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const { response } = await dialog.showMessageBox(win, {
    type: 'question', buttons: ['Clear history', 'Cancel'], defaultId: 1, cancelId: 1,
    message: 'Clear all browsing history?'
  });
  if (response !== 0) return false;
  historyCache = [];
  writeJson(file('history.json'), []);
  await session.defaultSession.clearCache();
  return true;
});

ipcMain.on('window:new', (e, opts) => {
  if (opts && opts.incognito && policy.allowIncognito === false) return;
  createWindow({ incognito: !!(opts && opts.incognito) });
});

// ---------- management server (optional) ----------
function syncWithServer() {
  const base = String(policy.managementServer || '').replace(/\/+$/, '');
  if (!base.startsWith('https://')) return; // HTTPS only
  const body = JSON.stringify({
    deviceId: deviceId(),
    hostname: os.hostname(),
    user: os.userInfo().username,
    os: `${os.type()} ${os.release()} ${os.arch()}`,
    browserVersion: app.getVersion(),
    chromiumVersion: process.versions.chrome
  });
  const req = net.request({ method: 'POST', url: `${base}/api/v1/devices/heartbeat` });
  req.setHeader('Content-Type', 'application/json');
  if (policy.enrollmentToken) req.setHeader('Authorization', `Bearer ${policy.enrollmentToken}`);
  let data = '';
  req.on('response', (res) => {
    res.on('data', (chunk) => { data += chunk; });
    res.on('end', () => {
      if (res.statusCode !== 200) return;
      try {
        const reply = JSON.parse(data);
        if (reply && typeof reply.policy === 'object') {
          writeJson(file('remote-policy.json'), reply.policy);
          policy = loadPolicy();
          broadcast('policy-updated');
        }
      } catch { /* ignore malformed reply */ }
    });
  });
  req.on('error', () => { /* offline: keep cached policy */ });
  req.end(body);
}

// ---------- app lifecycle ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => createWindow());
  app.setAppUserModelId('org.rdrsbangladesh.browser');

  app.whenReady().then(() => {
    configureSession(session.defaultSession);
    createWindow();
    syncWithServer();
    const minutes = Math.max(5, Number(policy.syncIntervalMinutes) || 15);
    setInterval(syncWithServer, minutes * 60 * 1000);
    // pick up edits to the machine policy file without restart
    setInterval(() => { policy = loadPolicy(); }, 60 * 1000);
  });

  app.on('window-all-closed', () => {
    if (historyCache) writeJson(file('history.json'), historyCache);
    app.quit();
  });
}
