# RDRS Browser 1.0

Managed web browser for RDRS Bangladesh, built on Electron 22 (Chromium 108 engine).

## Build the installer (one time, on any Windows 10/11 PC with internet)

1. Install Node.js 18 LTS or newer from https://nodejs.org
2. Unzip this folder, e.g. to `C:\rdrs-browser`
3. Double-click **build.bat**
4. After 3–10 minutes the installer appears in `dist\RDRS-Browser-Setup-1.0.0.exe`

To try the browser without building an installer, double-click **run-dev.bat**.

## Install on staff computers

- Normal install: double-click `RDRS-Browser-Setup-1.0.0.exe` (needs admin; installs to Program Files for all users, adds Desktop and Start menu shortcuts).
- Silent install (for IT, e.g. from a script or GPO): `RDRS-Browser-Setup-1.0.0.exe /S`
- Supported: Windows 7 SP1 x64, 8.1, 10, 11 (64-bit).
- The installer is not code-signed, so Windows SmartScreen will show "Windows protected your PC". Click **More info → Run anyway**, or buy a code-signing certificate and add it to `package.json` → `build.win`.

## Control the browser with a policy file

Policies are merged in this order (later wins):

1. Built-in defaults: `policy.default.json` (inside the app)
2. Policy sent by the management server (if configured)
3. Machine policy file: **`C:\ProgramData\RDRS\Browser\policy.json`**

IT can copy a `policy.json` to that folder on each PC (by hand, script, or GPO file copy). Only the keys you include are overridden. Changes are picked up within one minute; proxy changes need a browser restart.

| Key | Meaning |
|---|---|
| `homepage` | Start page; `rdrs://newtab/` is the RDRS new tab page |
| `searchUrl` | Search engine, `%s` is replaced by the search words |
| `urlBlocklist` | Domains to block, e.g. `["facebook.com", "youtube.com"]` (subdomains included) |
| `urlAllowlist` | Domains always allowed |
| `allowlistOnly` | `true` = block every site not in `urlAllowlist` |
| `downloadsDisabled` | `true` = block all downloads |
| `blockedDownloadExtensions` | File types that cannot be downloaded, e.g. `["exe","msi"]` |
| `allowDevTools` | `false` hides Developer tools (F12) |
| `allowIncognito` | `false` disables incognito windows |
| `proxy` | `{ "proxyRules": "http=10.0.0.1:8080;https=10.0.0.1:8080", "proxyBypassRules": "<local>;*.rdrs.local" }` |
| `quickLinks` | Tiles on the new tab page: `[{ "title": "HR Portal", "url": "http://..." }]` |
| `managedBookmarks` | Bookmarks every user sees (red dot; users cannot remove them) |
| `announcement` | Message shown on the new tab page |
| `managementServer`, `enrollmentToken`, `syncIntervalMinutes` | Central management (below) |

**Before building, edit `policy.default.json` and replace the placeholder addresses** (`hr.rdrs.local`, `payroll.rdrs.local`, `mis.rdrs.local`, `inventory.rdrs.local`, Email) with your real system URLs.

## Central management server (optional)

If `managementServer` is set to an `https://` address, every browser sends a heartbeat on start and every `syncIntervalMinutes`:

```
POST {managementServer}/api/v1/devices/heartbeat
Authorization: Bearer {enrollmentToken}
Content-Type: application/json

{ "deviceId": "uuid", "hostname": "PC-NAME", "user": "windows-user",
  "os": "Windows_NT 10.0.19045 x64", "browserVersion": "1.0.0", "chromiumVersion": "108.0.5359.215" }
```

Reply `200` with `{ "policy": { ...same keys as policy.json... } }` to push a policy, or `{}` for no change. This is the hook for the PHP 8.3 / MySQL management server: store the heartbeat in a `devices` table and return the policy assigned to that device or branch. If the server is unreachable, the last received policy is kept.

## Features in this version

Tabs, address/search bar, back/forward/reload/home, bookmarks bar, history page (`Ctrl+H`), downloads with policy checks, incognito windows, zoom, print, developer tools, RDRS new tab page with quick links and announcement, blocked-site page, website allow/block lists, proxy, single-instance, per-user data in `%APPDATA%\RDRS Browser`.

Keyboard: Ctrl+T new tab, Ctrl+W close tab, Ctrl+Tab / Ctrl+Shift+Tab switch tab, Ctrl+L address bar, Ctrl+D bookmark, Ctrl+H history, Ctrl+Shift+N incognito, F5 reload, F12 dev tools, Alt+Left/Right back/forward, Ctrl +/−/0 zoom.

Not yet included: Chrome Web Store extensions, built-in password manager, sync, auto-update, session restore, Safe Browsing service.

## Important security note on Windows 7 / 8.1

Electron 22 is the last version that runs on Windows 7/8/8.1, and its Chromium 108 engine no longer receives security fixes. It is fine for internal RDRS systems, but browsing the open internet on it carries risk. Plan to move those PCs to Windows 10/11; for those PCs you can later build a second installer with a current `electron` version in `package.json` (small code updates may be needed).
