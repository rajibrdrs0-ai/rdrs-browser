'use strict';
let items = [];
const list = document.getElementById('list');

function render(term) {
  term = (term || '').toLowerCase();
  list.textContent = '';
  let day = null, ul = null, shown = 0;
  for (const it of items) {
    if (term && !(it.title || '').toLowerCase().includes(term) && !it.url.toLowerCase().includes(term)) continue;
    if (++shown > 1000) break;
    const d = new Date(it.time);
    const dayLabel = d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    if (dayLabel !== day) {
      day = dayLabel;
      const h = document.createElement('h2'); h.textContent = dayLabel; list.appendChild(h);
      ul = document.createElement('ul'); list.appendChild(ul);
    }
    const li = document.createElement('li');
    const t = document.createElement('time'); t.textContent = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    const a = document.createElement('a'); a.href = it.url; a.textContent = it.title || it.url;
    const host = document.createElement('small'); try { host.textContent = new URL(it.url).hostname; } catch {}
    a.appendChild(host);
    li.append(t, a); ul.appendChild(li);
  }
  if (!shown) { const p = document.createElement('p'); p.className = 'empty'; p.textContent = term ? 'No pages match your search.' : 'Pages you visit will appear here.'; list.appendChild(p); }
}

fetch('data.json').then((r) => r.json()).then((d) => { items = Array.isArray(d) ? d : []; render(); }).catch(() => render());
document.getElementById('filter').addEventListener('input', (e) => render(e.target.value));
