'use strict';
const cfg = { searchUrl: 'https://www.google.com/search?q=%s', quickLinks: [], announcement: '' };

function toUrl(t) {
  t = t.trim();
  if (!t) return null;
  if (/^(https?|rdrs):\/\//i.test(t)) return t;
  if (/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t)) return 'http://' + t;
  if (!/\s/.test(t) && /^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(t)) return (/\.local(:\d+)?(\/|$)/i.test(t) ? 'http://' : 'https://') + t;
  return cfg.searchUrl.replace('%s', encodeURIComponent(t));
}

document.getElementById('search').addEventListener('submit', (e) => {
  e.preventDefault();
  const url = toUrl(document.getElementById('q').value);
  if (url) location.href = url;
});

function renderDate() {
  const now = new Date();
  const opts = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Dhaka' };
  const time = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Dhaka' });
  document.getElementById('today').textContent = `${now.toLocaleDateString('en-GB', opts)}, ${time}`;
}
renderDate();
setInterval(renderDate, 30000);

fetch('config.json').then((r) => r.json()).then((c) => {
  Object.assign(cfg, c);
  if (c.orgName) document.getElementById('org').textContent = c.orgName;
  const tiles = document.getElementById('tiles');
  (c.quickLinks || []).forEach((l) => {
    const a = document.createElement('a');
    a.className = 'tile';
    a.href = l.url;
    a.title = l.url;
    const mark = document.createElement('span');
    mark.className = 'mark';
    mark.textContent = (l.title || '?').trim().charAt(0).toUpperCase();
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = l.title;
    a.append(mark, label);
    tiles.appendChild(a);
  });
  if (c.announcement) {
    document.getElementById('announcement').textContent = c.announcement;
    document.getElementById('notice').hidden = false;
  }
}).catch(() => {});
