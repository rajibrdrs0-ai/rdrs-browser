'use strict';
// Exposes a small, safe API to the browser UI (not to web pages).
const { contextBridge, ipcRenderer } = require('electron');

const CHANNELS = ['open-tab', 'shortcut', 'toast', 'policy-updated'];

contextBridge.exposeInMainWorld('rdrs', {
  getPolicy: () => ipcRenderer.invoke('policy:get'),
  getBookmarks: () => ipcRenderer.invoke('bookmarks:get'),
  saveBookmarks: (list) => ipcRenderer.invoke('bookmarks:save', list),
  addHistory: (entry) => ipcRenderer.send('history:add', entry),
  clearHistory: () => ipcRenderer.invoke('history:clear'),
  newWindow: (incognito) => ipcRenderer.send('window:new', { incognito: !!incognito }),
  on: (channel, fn) => {
    if (CHANNELS.includes(channel)) ipcRenderer.on(channel, (e, ...args) => fn(...args));
  }
});
