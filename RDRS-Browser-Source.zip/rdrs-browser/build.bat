@echo off
title RDRS Browser - build installer
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is not installed. Install Node.js 18 LTS or newer from https://nodejs.org
  echo then run this file again.
  pause
  exit /b 1
)

echo [1/2] Downloading build tools (Electron, electron-builder)... this needs internet.
call npm install
if errorlevel 1 goto failed

echo [2/2] Building the Windows installer...
call npm run dist
if errorlevel 1 goto failed

echo.
echo Done. Your installer is in the "dist" folder:
dir /b dist\*.exe
explorer dist
pause
exit /b 0

:failed
echo.
echo Build failed. Scroll up to see the error message.
pause
exit /b 1
