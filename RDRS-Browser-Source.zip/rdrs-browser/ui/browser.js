'use strict';
/* global rdrs */
const params = new URLSearchParams(location.search);
const INCOGNITO = params.get('incognito') === '1';
const NEWTAB = 'rdrs://newtab/';
const ERR_BLOCKED_BY_CLIENT = -20;
const ERR_ABORTED = -3;

const $ = (id) => document.getElementById(id);
const tabsEl = $('tabs');
const viewsEl = $('views');
const address = $('address');

let policy = { homepage: NEWTAB, searchUrl: 'https://www.google.com/search?q=%s', allowDevTools: true, managedBookmarks: [] };
let bookmarks = [];
const tabs = [];
let active = null;
let seq = 0;

if (INCOGNITO) { document.body.classList.add('incognito'); $('incognito-badge').hidden = false; document.title = 'RDRS Browser (Incognito)'; }

// ---------- address bar input ----------
function toUrl(text) {
  const t = text.trim();
  if (!t) return null;
  if (/^(https?|rdrs):\/\//i.test(t)) return t;
  if (/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t)) return 'http://' + t;
  if (!/\s/.test(t) && /^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(t)) {
    return (/\.local(:\d+)?(\/|$)/i.test(t) ? 'http://' : 'https://') + t;
  }
  return policy.searchUrl.replace('%s', encodeURIComponent(t));
}
function displayUrl(url) {
  return !url || url.startsWith(NEWTAB) ? '' : url;
}

// ---------- tabs ----------
function createTab(url, { background = false } = {}) {
  const id = ++seq;
  const el = document.createElement('div');
  el.className = 'tab';
  el.setAttribute('role', 'tab');
  el.tabIndex = 0;
  el.innerHTML = '<span class="spinner"></span><img class="fav" alt=""><span class="title">New tab</span>' +
    '<button class="close" aria-label="Close tab" title="Close tab (Ctrl+W)"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>';
  const fav = el.querySelector('.fav');
  fav.src = 'rdrs://newtab/logo.png';

  const wv = document.createElement('webview');
  wv.setAttribute('allowpopups', '');
  if (INCOGNITO) wv.setAttribute('partition', 'rdrs-incognito');
  wv.setAttribute('src', url || policy.homepage || NEWTAB);

  const tab = { id, el, wv, title: 'New tab', url: url || NEWTAB, loading: false, ready: false };
  tabs.push(tab);
  tabsEl.appendChild(el);
  viewsEl.appendChild(wv);

  el.addEventListener('mousedown', (e) => {
    if (e.button === 1) { e.preventDefault(); closeTab(tab); }
    else if (e.button === 0 && !e.target.closest('.close')) activate(tab);
  });
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') activate(tab); });
  el.querySelector('.close').addEventListener('click', () => closeTab(tab));

  wv.addEventListener('dom-ready', () => { tab.ready = true; refresh(); });
  wv.addEventListener('page-title-updated', (e) => {
    tab.title = e.title;
    el.querySelector('.title').textContent = e.title;
    el.title = e.title;
    if (tab === active) document.title = `${e.title} - RDRS Browser`;
    if (!INCOGNITO) rdrs.addHistory({ url: tab.url, title: e.title });
  });
  wv.addEventListener('page-favicon-updated', (e) => { if (e.favicons && e.favicons[0]) fav.src = e.favicons[0]; });
  wv.addEventListener('did-start-loading', () => { tab.loading = true; el.classList.add('loading'); refresh(); });
  wv.addEventListener('did-stop-loading', () => { tab.loading = false; el.classList.remove('loading'); refresh(); });
  const onNav = (e) => {
    if (e.isMainFrame === false) return;
    tab.url = e.url;
    if (e.url.startsWith('rdrs://')) fav.src = 'rdrs://newtab/logo.png';
    refresh();
  };
  wv.addEventListener('did-navigate', (e) => { fav.src = 'rdrs://newtab/logo.png'; onNav(e); });
  wv.addEventListener('did-navigate-in-page', onNav);
  wv.addEventListener('did-fail-load', (e) => {
    if (!e.isMainFrame) return;
    if (e.errorCode === ERR_BLOCKED_BY_CLIENT) {
      wv.loadURL('rdrs://blocked/?url=' + encodeURIComponent(e.validatedURL));
    } else if (e.errorCode !== ERR_ABORTED) {
      wv.loadURL('rdrs://error/?url=' + encodeURIComponent(e.validatedURL) + '&code=' + e.errorCode + '&desc=' + encodeURIComponent(e.errorDescription));
    }
  });

  if (!background || !active) activate(tab);
  if (!url || url === NEWTAB) setTimeout(() => address.focus(), 50);
  return tab;
}

function activate(tab) {
  if (!tab) return;
  active = tab;
  tabs.forEach((t) => {
    const on = t === tab;
    t.el.classList.toggle('active', on);
    t.el.setAttribute('aria-selected', on);
    t.wv.classList.toggle('active', on);
  });
  tab.el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  document.title = `${tab.title} - RDRS Browser`;
  refresh();
  if (tab.ready) tab.wv.focus();
}

function closeTab(tab) {
  const i = tabs.indexOf(tab);
  if (i < 0) return;
  tabs.splice(i, 1);
  tab.el.remove();
  tab.wv.remove();
  if (!tabs.length) { window.close(); return; }
  if (active === tab) activate(tabs[Math.min(i, tabs.length - 1)]);
}

function cycle(step) {
  if (tabs.length < 2) return;
  const i = tabs.indexOf(active);
  activate(tabs[(i + step + tabs.length) % tabs.length]);
}

function navigate(input) {
  const url = toUrl(input);
  if (!url || !active) return;
  active.wv.loadURL(url);
  active.wv.focus();
}

// ---------- toolbar state ----------
function refresh() {
  const t = active;
  if (!t) return;
  const ready = t.ready;
  $('btn-back').disabled = !(ready && t.wv.canGoBack());
  $('btn-forward').disabled = !(ready && t.wv.canGoForward());
  document.body.classList.toggle('loading', t.loading);
  if (document.activeElement !== address) address.value = displayUrl(t.url);
  const si = $('secure-icon');
  si.className = t.url.startsWith('https://') ? 'secure' : t.url.startsWith('http://') ? 'insecure' : '';
  si.title = si.className === 'insecure' ? 'Not secure' : si.className === 'secure' ? 'Connection is secure' : '';
  $('btn-star').classList.toggle('on', bookmarks.some((b) => b.url === t.url));
}

// ---------- bookmarks ----------
function renderBookmarks() {
  const bar = $('bookmarkbar');
  bar.textContent = '';
  const add = (b, managed) => {
    const a = document.createElement('a');
    a.href = b.url;
    a.textContent = b.title || b.url;
    a.title = managed ? `${b.title} (set by RDRS IT)` : `${b.title}\n${b.url}\nRight-click to remove`;
    if (managed) a.className = 'managed';
    a.addEventListener('click', (e) => {
      e.preventDefault();
      if (e.ctrlKey || e.button === 1) createTab(b.url, { background: true }); else active.wv.loadURL(b.url);
    });
    a.addEventListener('auxclick', (e) => { if (e.button === 1) { e.preventDefault(); createTab(b.url, { background: true }); } });
    if (!managed) a.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      if (confirm(`Remove bookmark "${b.title}"?`)) { bookmarks = bookmarks.filter((x) => x !== b); saveBookmarks(); }
    });
    bar.appendChild(a);
  };
  (policy.managedBookmarks || []).forEach((b) => add(b, true));
  bookmarks.forEach((b) => add(b, false));
}
async function saveBookmarks() {
  await rdrs.saveBookmarks(bookmarks);
  renderBookmarks();
  refresh();
}
function toggleBookmark() {
  if (!active || !/^https?:/.test(active.url)) return;
  const i = bookmarks.findIndex((b) => b.url === active.url);
  if (i >= 0) { bookmarks.splice(i, 1); toast('Bookmark removed'); }
  else { bookmarks.push({ title: active.title || active.url, url: active.url }); toast('Bookmark added'); }
  saveBookmarks();
}

// ---------- menu & commands ----------
const menu = $('menu');
function toggleMenu(show = menu.hidden) {
  menu.hidden = !show;
  $('btn-menu').setAttribute('aria-expanded', show);
  if (show) menu.querySelector('button').focus();
}

async function command(cmd) {
  const wv = active && active.wv;
  switch (cmd) {
    case 'new-tab': createTab(); break;
    case 'new-window': rdrs.newWindow(false); break;
    case 'incognito': rdrs.newWindow(true); break;
    case 'close-tab': closeTab(active); break;
    case 'next-tab': cycle(1); break;
    case 'prev-tab': cycle(-1); break;
    case 'focus-address': address.focus(); address.select(); break;
    case 'reload': wv && wv.reload(); break;
    case 'back': wv && wv.canGoBack() && wv.goBack(); break;
    case 'forward': wv && wv.canGoForward() && wv.goForward(); break;
    case 'bookmark': toggleBookmark(); break;
    case 'history': createTab('rdrs://history/'); break;
    case 'clear-history': if (await rdrs.clearHistory()) toast('Browsing history cleared'); break;
    case 'zoom-in': wv && wv.setZoomLevel(Math.min(wv.getZoomLevel() + 0.5, 5)); break;
    case 'zoom-out': wv && wv.setZoomLevel(Math.max(wv.getZoomLevel() - 0.5, -4)); break;
    case 'zoom-reset': wv && wv.setZoomLevel(0); break;
    case 'print': wv && wv.print(); break;
    case 'devtools':
      if (!policy.allowDevTools) { toast('Developer tools are disabled by RDRS policy'); break; }
      if (wv) wv.isDevToolsOpened() ? wv.closeDevTools() : wv.openDevTools();
      break;
    case 'about':
      alert(`RDRS Browser ${policy.version}\nChromium ${policy.chromium}\nDevice ID: ${policy.deviceId}\n\n${policy.orgName || 'RDRS Bangladesh'}`);
      break;
  }
}

let toastTimer;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 3500);
}

// ---------- wiring ----------
$('btn-newtab').addEventListener('click', () => createTab());
$('btn-back').addEventListener('click', () => command('back'));
$('btn-forward').addEventListener('click', () => command('forward'));
$('btn-reload').addEventListener('click', () => (active && active.loading ? active.wv.stop() : command('reload')));
$('btn-home').addEventListener('click', () => active && active.wv.loadURL(policy.homepage || NEWTAB));
$('btn-star').addEventListener('click', toggleBookmark);
$('btn-menu').addEventListener('click', (e) => { e.stopPropagation(); toggleMenu(); });
menu.addEventListener('click', (e) => {
  const b = e.target.closest('button[data-cmd]');
  if (!b) return;
  toggleMenu(false);
  command(b.dataset.cmd);
});
document.addEventListener('click', (e) => { if (!menu.hidden && !menu.contains(e.target)) toggleMenu(false); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !menu.hidden) { toggleMenu(false); $('btn-menu').focus(); } });
window.addEventListener('blur', () => toggleMenu(false));

$('omnibox').addEventListener('submit', (e) => { e.preventDefault(); navigate(address.value); });
address.addEventListener('focus', () => setTimeout(() => address.select(), 0));
address.addEventListener('keydown', (e) => { if (e.key === 'Escape') { address.value = displayUrl(active.url); active.wv.focus(); } });
address.addEventListener('blur', () => { if (active) address.value = displayUrl(active.url); });

rdrs.on('open-tab', (url) => createTab(url));
rdrs.on('shortcut', (action) => command(action));
rdrs.on('toast', (msg) => toast(msg));
rdrs.on('policy-updated', async () => { policy = await rdrs.getPolicy(); applyPolicyToUi(); renderBookmarks(); });

function applyPolicyToUi() {
  $('menu-devtools').hidden = !policy.allowDevTools;
  $('menu-incognito').hidden = !policy.allowIncognito || INCOGNITO;
}

// ---------- start ----------
(async function init() {
  try { policy = await rdrs.getPolicy(); } catch { /* use defaults */ }
  try { bookmarks = await rdrs.getBookmarks(); } catch { bookmarks = []; }
  applyPolicyToUi();
  renderBookmarks();
  createTab(params.get('url') || policy.homepage || NEWTAB);
})();
